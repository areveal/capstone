<?php
$output = $el_class = $width = '';
extract(shortcode_atts(array(
    'el_class' => '',
    'width' => '1/1',
    'css' => ''
), $atts));

$el_class = $this->getExtraClass( $el_class );
$width = wpb_translateColumnWidthToSpan( $width, false );

$el_class .= ' wpb_column column_container';

$css_class = preg_replace( '/vc_span(\d{1,2})/', 'col-sm-$1', $width.$el_class.vc_shortcode_custom_css_class($css, ' ') );

$output .= "\n\t".'<div class="'.$css_class.'">';
$output .= "\n\t\t".'<div class="wpb_wrapper">';
$output .= "\n\t\t\t".wpb_js_remove_wpautop($content);
$output .= "\n\t\t".'</div> '.$this->endBlockComment('.wpb_wrapper');
$output .= "\n\t".'</div> '.$this->endBlockComment($el_class) . "\n";

echo $output;