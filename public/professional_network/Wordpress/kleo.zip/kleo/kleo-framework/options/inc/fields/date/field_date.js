/*global jQuery*/

(function($) {
    "use strict";

    $(document).ready(function() {
        $('.redux-datepicker').each(function() {
            $(this).datepicker();
        });
    });
})(jQuery);